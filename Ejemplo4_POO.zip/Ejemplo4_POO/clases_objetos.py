class Persona:
    
    # constructor para poder crear los objetos
    def __init__(self, nombre, edad=18) -> None:
        # self -> apunta a la propia instancia
        self.nombre = nombre
        self.edad = edad
        
    def mostrarInfo(self) :
        # print("Hola, me llamo",self.nombre,  "y tengo", self.edad, "años")
        print("Hola, me llamo {} y tengo {} años".format(self.nombre, self.edad))
        
        
# Crear objetos o instancias de Persona
juan = Persona("Juan", 27)
maria = Persona("Maria", 35)
laura = Persona("Laura")

# Invocar a los recursos del objeto
juan.mostrarInfo()
maria.mostrarInfo()
laura.mostrarInfo()

# Los atributos o propiedades son publicas
juan.edad = 28
juan.mostrarInfo()