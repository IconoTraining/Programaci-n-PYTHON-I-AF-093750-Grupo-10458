'''
    Una clase encapsulada tiene todos sus atributos privados y solo
    se accede a ellos a través de metodos get y set publicos
'''

class Fecha:
    def __init__(self, dia, mes, anyo) -> None:
        self.setDia(dia)
        self.setMes(mes)
        self.setAnyo(anyo)
        
    def getDia(self):
        return self.__dia
    
    def setDia(self, dia):
        # los dias son entre 1 y 30
        if dia > 0 and dia <= 30 :
            self.__dia = dia
        else :
            self.__dia = 0
     
    def getMes(self):
        return self.__mes
    
    def setMes(self, mes):
        # los meses son entre 1 y 12
        if mes > 0 and mes <= 12 :
            self.__mes = mes
        else :
            self.__mes = 0       
    
    def getAnyo(self):
        return self.__anyo
    
    def setAnyo(self, anyo):
        # Año valido 2022 o 2023
        if anyo == 2022 or anyo == 2023 :
            self.__anyo = anyo
        else :
            self.__anyo = 0 
    
    def mostrar(self) :
        print(self.__dia, self.__mes, self.__anyo, sep="/")


# Crear fechas
hoy = Fecha(-6667,1231,-0)
hoy.mostrar()

buena = Fecha(23,11,2022)
buena.mostrar()

# No podemos acceder a los recursos privados
hoy.__dia = 25   # No da error pero lo ignora
print(hoy.getDia())

'''
class Fecha:
    def __init__(self, dia, mes, anyo) -> None:
        self.dia = dia
        self.mes = mes
        self.anyo = anyo
        
    def mostrar(self) :
        print(self.dia, self.mes, self.anyo, sep="/")
        
        
# Crear fechas
hoy = Fecha(-6667,1231,-0)
hoy.mostrar()
'''