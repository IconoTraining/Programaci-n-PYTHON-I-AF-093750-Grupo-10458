class Direccion:
    def __init__(self, calle, numero, poblacion) -> None:
        self.calle = calle
        self.numero = numero
        self.poblacion = poblacion
        
    def mostrar(self):
        # Mayor, 5 - Madrid
        return self.calle + ", " + str(self.numero) + " - " + self.poblacion
    
    
class Persona:
    def __init__(self, nombre, edad, direccion) -> None:
        self.nombre = nombre
        self.edad = edad
        self.direccion = direccion
        
    def mostrarInfo(self) :
        print("Hola, me llamo {}, tengo {} años y vivo en {}"
              .format(self.nombre, self.edad, self.direccion.mostrar()))
   
   
# Crear la direccion de Juan
dirJuan = Direccion("Mayor", 5, "Madrid")

# Crear la instancia de Persona
juan = Persona("Juan", 27, dirJuan)

juan.mostrarInfo()

# Crear una instancia de Persona con direccion
maria = Persona("Maria", 35, Direccion("Diagonal",127,"Barcelona"))
maria.mostrarInfo()

laura = Persona("Laura", 19, Direccion("Real", 45, "Sevilla") )
laura.mostrarInfo()
print(laura.direccion.poblacion)
print(juan.direccion.calle)
print(laura.direccion)
print(laura.direccion.mostrar())