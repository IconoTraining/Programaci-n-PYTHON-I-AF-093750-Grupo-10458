class Animal:
    def __init__(self, nombre, edad) -> None:
        self.nombre = nombre
        self.edad = edad
        
    def mostrarInfo(self) :
        return "Nombre: {} Edad: {}".format(self.nombre, self.edad)


class ProductoVenta:
    def __init__(self, codigo, precio) -> None:
        self.codigo = codigo
        self.precio = precio
        
    def mostrarInfo(self) :
        return "Codigo: {} Precio: {}".format(self.codigo, self.precio)
    
    
# herencia multiple
class Perro(Animal, ProductoVenta):
    def __init__(self, nombre, edad, codigo, precio, vacunado, sexo) -> None:
        Animal.__init__(self, nombre, edad)
        ProductoVenta.__init__(self, codigo, precio)
        self.vacunado = vacunado
        self.sexo = sexo
        
    def mostrarInfo(self) :
        return Animal.mostrarInfo(self) + ProductoVenta.mostrarInfo(self) + " Vacunado: {} Sexo: {}".format(self.vacunado, self.sexo)
        
        
# Crear el objeto Perro
perro = Perro("Fifi", 4, "PE-001", 225, True, "Macho")
print(perro.mostrarInfo())