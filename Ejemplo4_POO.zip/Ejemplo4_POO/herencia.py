class Persona:
    def __init__(self, nombre, edad) -> None:
        self.nombre = nombre
        self.edad = edad
        
    def mostrarInfo(self) :
        return "Hola, me llamo {} y tengo {} años".format(self.nombre, self.edad)

 
class Empleado(Persona) :
    def __init__(self, nombre, edad, sueldo) -> None:
        super().__init__(nombre, edad)
        self.sueldo = sueldo
    
    def info(self):
        return super().mostrarInfo() + " mi sueldo es " + str(self.sueldo)
    

# crear un empleado
juan = Empleado("Juan", 27, 35000)
print(juan.info())