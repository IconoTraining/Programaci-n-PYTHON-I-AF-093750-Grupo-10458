# Primera forma de importar el modulo
'''
import persona

# Sintaxis: modulo.Clase
p1 = persona.Persona("Luis", 45)
p1.mostrarInfo()
'''

# Segunda forma
'''
from persona import Persona

p1 = Persona("Luis", 45)
p1.mostrarInfo()
'''

# Tercera forma

from persona import Persona as Pers

p1 = Pers("Luis", 45)
p1.mostrarInfo()