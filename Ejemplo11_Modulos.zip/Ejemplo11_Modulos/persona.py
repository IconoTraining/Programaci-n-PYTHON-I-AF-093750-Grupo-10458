class Persona:
    def __init__(self, nombre, edad) -> None:
        self.nombre = nombre
        self.edad = edad
        
    def mostrarInfo(self) :
        print("Hola, me llamo {} y tengo {} años".format(self.nombre, self.edad))
