# sumar los numeros
datos = ['1', '2', 'tres', '4', '5']
suma = 0

import traceback

for i in range(len(datos) + 1):
    try:
        # acceder al dato
        dato = datos[i]
        
        # lo convierto a numero
        numero = int(dato)
        
    except (ValueError, IndexError, Exception) as ex:
        print("Error de tipo", type(ex))
        print("Ha ocurrido un error", ex)  # mensaje
        traceback.print_exc() # stack trace
        
    else:
        # sumamos el numero
        suma += numero
        
print("Suma:", suma)