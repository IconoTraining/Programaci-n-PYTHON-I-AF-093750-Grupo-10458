# try-except-else-finally

import traceback

try:
    numero1 = int(input("Introduce dividendo: "))
    numero2 = int(input("Introduce divisor: "))
    division = numero1 / numero2
except ZeroDivisionError as error:
    print("No se puede dividir por cero", error)
    # mostrar la pila de llamadas - stack trace
    traceback.print_exc()
except ValueError as e:
    print("El valor introducido no es numerico", e) 
    # mostrar la pila de llamadas - stack trace
    traceback.print_exc()   
except Exception as ex:
    print("Ha ocurrido un error", ex)
    print("Error de tipo", type(ex))
    # mostrar la pila de llamadas - stack trace
    traceback.print_exc()
else:
    # se ejecuta si no ha ocurrido ningun error
    print("Resultado:", division)
finally:
    # Siempre se ejecuta, haya error o no
    print("****** FIN ******")