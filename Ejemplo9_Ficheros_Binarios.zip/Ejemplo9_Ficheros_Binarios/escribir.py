import pickle

nombres = ['Juan', 'Maria', 'Pedro', 'Pablo', 'Laura']
fichero = open("Ejemplo9_Ficheros_Binarios/fichero.pckl","wb")
pickle.dump(nombres, fichero)
fichero.close()