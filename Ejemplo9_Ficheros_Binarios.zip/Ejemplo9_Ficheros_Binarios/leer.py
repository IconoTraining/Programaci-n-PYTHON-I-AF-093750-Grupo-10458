import pickle

fichero = open("Ejemplo9_Ficheros_Binarios/fichero.pckl","rb")
nombres = pickle.load(fichero)
print(nombres)
print(type(nombres))

fichero.close()