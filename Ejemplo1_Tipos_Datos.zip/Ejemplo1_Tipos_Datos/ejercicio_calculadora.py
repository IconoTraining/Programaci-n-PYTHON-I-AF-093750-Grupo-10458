'''
    solicitar 2 numeros al usuario
    aplicar conversion
    mostrar suma, resta, multiplicacion, division, modulo, potencia
'''

numero1 = int(input("Introduce un numero: "))
numero2 = int(input("Introduce otro numero: "))

print("Suma:", numero1 + numero2)
print("Resta:", numero1 - numero2)
print("Multiplicación:", numero1 * numero2)
print("División:", numero1 / numero2)
print("Modulo:", numero1 % numero2)
print("Potencia:", numero1 ** numero2)
print("División entera:", numero1 // numero2)