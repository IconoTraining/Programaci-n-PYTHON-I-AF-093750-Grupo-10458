texto = "bienvenidos al curso de Python"
# texto: str = "bienvenidos al curso de Python"   de forma optativa se puede poner el tipo
print(texto)

print(texto.capitalize())
print(texto.upper())
print(texto.lower())

print(texto.isalnum())  # False porque tiene espacios en blanco
print("Pepito".isalnum())
print("12345".isalnum())

print(texto.isalpha()) # False porque tiene espacios en blanco
print("Pepito".isalpha())
print("12345".isalpha())

print(texto.isdigit())  # False porque todo es texto y espacios en blanco
print("12345".isdigit())

print(texto.isupper())
print(texto.islower())

ejemplo = "    lunes       "
print(ejemplo, end=".\n")
print(ejemplo.lstrip(), end=".\n")   # left
print(ejemplo.rstrip(), end=".\n")   # right
print(ejemplo.strip(), end=".\n")    # ambos lados

print("Longitud:", len(texto))
print("Longitud:", texto.__len__())

print("Max:", max(texto))
print("Max:", max("aA7"))   # orden tabla ASCII: numeros, mayusculas, minusculas
print("Min:", min(texto))
print("Min:", min("aA7"))

print(texto.replace('e','E'))   # cambia todas las E
print(texto.replace('e','E', 1))   # cambia solo la primera ocurrencia

palabras = texto.split()    # trocea la cadena por el espacio en blanco
print(palabras)
print(type(palabras))   # list

fecha = "21/11/2022"
datos = fecha.split("/")
print("Dia:", datos[0])
print("Mes:", datos[1])
print("Año:", datos[2])

print(texto.swapcase())

