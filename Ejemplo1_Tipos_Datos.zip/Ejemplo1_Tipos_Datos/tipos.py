'''
    Ejemplo de tipos de datos en Python
'''

# numeros enteros (int)
numero1 = 5
numero2 = 4
suma = numero1 + numero2
print(suma)
print("Suma:", suma, type(suma))
print("Suma: " + str(suma) + " " + str(type(suma)))  # concatenar en Python es mas complicado

# numeros reales (float)
base = 5.78
altura = 9.23
triangulo = base * altura / 2
print("Area del triangulo:", triangulo, type(triangulo))

# booleanos: True o False (bool)
soltero = True
print("Estas soltero?", soltero, type(soltero))

# cadenas de texto (str)
# se pueden utilizar comillas simples o dobles
nombre = "Pepito"
apellido = 'Perez'
print(nombre, apellido, type(nombre))