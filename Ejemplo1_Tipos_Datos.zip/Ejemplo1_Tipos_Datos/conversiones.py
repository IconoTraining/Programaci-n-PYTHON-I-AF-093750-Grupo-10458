import math

# convertir de texto a numero entero
dato = input("Introduce un numero: ")
print(type(dato))  # str
numero1 = int(dato)  # lo convertimos a numero entero

numero2 = int(input("Introduce otro numero: "))
suma = numero1 + numero2
print("Suma:", suma)

# convertir de texto a numero real
radio = float(input("Introduce el radio de un circulo: "))
print("Area del circulo", math.pi*radio**2)   # ** es una potencia
print("Area del circulo", round(math.pi*radio**2, 2))  #round(que, decimales)

# convertir a texto
texto = str(suma)
print(type(texto))

soltero = True
print(type(str(soltero)))