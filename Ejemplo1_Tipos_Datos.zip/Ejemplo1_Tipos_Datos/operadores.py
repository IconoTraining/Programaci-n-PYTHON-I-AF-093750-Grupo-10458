# Operadores aritmeticos (+,-,*,/,%,**,//)
numero1 = 7
numero2 = 2
print("Resto:", numero1 % numero2)
print("Potencia:", numero1**numero2)
print("Division:", numero1/numero2)
print("Division entera:", numero1//numero2)

# Operadores de asignacion (+=,-=,*=,/=,%=,**=,//=)
#numero1 = numero1 + 3
numero1 += 3
print(numero1)

# En Python no existen los incrementos, ni decrementos
# numero1++

# Operadores de comparacion (<, >, <=, >=, ==, !=)
print("Menor:", numero1 < numero2)
print("Distintos:", numero1 != numero2)
print("Iguales:", numero1 == numero2)

# Operadores logicos (and, or, not)
print("and:", (numero1 > numero2 and numero2 == 2))  # True
print("or:", (numero1 < numero2 or numero2 == 2))    # True
print("not:", not(numero1 < numero2))                # True

# Operadores de identidad(is,is not)
num1 = 6
num2 = 6
print("Mismo contenido", num1 == num2)
print("Mismo contenido", num1 is num2)  # Las 2 variables tienen el mismo contenido

nombres1 = ['Juan', 'Maria']
nombres2 = ['Juan', 'Maria']
print("Mismo contenido", nombres1 == nombres2)  # True, las listas son iguales
print("Mismo contenido", nombres1 is nombres2)  # False, las variables contienen direcciones de memoria distintas


# Operadores de pertenencia (in, not in)
print('Luis' in nombres1)     # False
print('Maria' in nombres1)    # True
print('Luis' not in nombres1) # True