def datosTrabajador(nombre, estadoCivil="Soltero", sueldo=21000) :
    return nombre + " esta " + estadoCivil + " y gana " + str(sueldo)

# Formas de llamar a la funcion
print(datosTrabajador("Juan"))
#print(datosTrabajador("Maria", 35000)) # Error, interpreta 35000 como estado civil
print(datosTrabajador("Jorge", sueldo=38000))

print(datosTrabajador("Maria", "Casada", 35000))
print(datosTrabajador("Luis", "Separado"))

print(datosTrabajador("Maria", sueldo=35000))


def concatenar(*datos, separador=' | '):
    return separador.join(datos)

print(concatenar("lunes","martes","miercoles","jueves","viernes","sabado","domingo"))
print(concatenar("lunes","martes","miercoles","jueves","viernes","sabado","domingo", separador=" - "))
print(concatenar("lunes","martes","miercoles","jueves","viernes","sabado","domingo", separador=","))
print(concatenar("lunes","martes","miercoles","jueves","viernes","sabado","domingo", separador="*"))