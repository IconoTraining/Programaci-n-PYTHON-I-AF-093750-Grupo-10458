# Funcion con numero variable de argumentos
def sumar(*numeros):
    suma = 0
    for num in numeros:
        suma += num
    return suma

print(sumar())
print(sumar(2))
print(sumar(2,8))
print(sumar(2,8,5))
print(sumar(5,1,9,6,2,4)) 


# crear una funcion que recibe el nombre del alumno y las notas de cada alumno
# utilizando la funcion sumar() calcular la nota media
# la funcion devuelve el nombre en mayusculas y la nota media
def procesarNotas(nombre, *notas) :
    notaMedia = sumar(*notas) / len(notas)
    return nombre.upper(), notaMedia

print(procesarNotas("Juan", 4,9,7,1))
print(procesarNotas("Maria", 7,9))
print(procesarNotas("Antonio", 8))
print(procesarNotas("Lucia", 6,7,5,8,4))

lista = (1,2,3,4,5)
print(sumar(*lista))