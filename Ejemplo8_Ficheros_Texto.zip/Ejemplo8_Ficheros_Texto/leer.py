# Abrir el fichero en modo lectura

# ruta absoluta
# fichero = open("/Users/anaisabelvegascaceres/Desktop/Python_BBVA_21_Noviembre/Ejemplo8_Ficheros_Texto/fichero.txt", "rt", encoding="utf-8")

# ruta relativa
fichero = open("Ejemplo8_Ficheros_Texto/fichero.txt", "rt", encoding="utf-8")

# leer todo el contenido
texto = fichero.read()
print(texto)

# mover el puntero al primera caracter
fichero.seek(0)

# leer la primera linea
linea = fichero.readline()
print(linea, end="")

# leer todas las lineas y las proceso una a una
fichero.seek(0)
lineas = fichero.readlines()
for linea in lineas:
    print(linea, end="")
print()

# crear una lista con el contenido del fichero
fichero.seek(0)
lista = list(fichero)
print(lista)
for linea in lista:
    print(linea, end="")
print()

# cerrar el fichero
fichero.close()