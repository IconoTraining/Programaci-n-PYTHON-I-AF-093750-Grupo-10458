'''
    abrir el fichero, en modo lectura escritura "a+t"
    leer el fichero.txt y copiarlo en ficheroWrite.txt
    mostrar el contenido ficheroWrite.txt
'''

# abrir el fichero en modo lectura
ficheroLectura = open("Ejemplo8_Ficheros_Texto/fichero.txt", "rt", encoding="utf-8")

# abrir el fichero en modo escritura
ficheroEscritura = open("Ejemplo8_Ficheros_Texto/ficheroWrite.txt", "a+t", encoding="utf-8")

# leer el contenido del fichero
contenido = list(ficheroLectura)

# escribir cada linea
for linea in contenido:
    ficheroEscritura.write(linea)
    
# leer el contenido creado
ficheroEscritura.seek(0)
for linea in ficheroEscritura.readlines():
    print(linea, end="")
print()

# cerrar los ficheros
ficheroLectura.close()
ficheroEscritura.close()