# La funcion reduce le pasamos una coleccion y
# retorna un solo resultado
# la funcion recibe 2 parametros:
#    - el primero actua como acumulador
#    - el segundo es el valor recibido
# la primera vez que se invoca a la funcion el primer item se guarda como acumulador
# y el segundo item sera el elemento a recibir
# sintaxis: reduce(funcion, coleccion)

''' Para utilizar reduce hay que importarlo '''
from functools import reduce

# Ejemplo 1
numeros = [3,8,4,15,30]

def sumar(acum, num):
    return acum + num

print("Suma:", reduce(sumar, numeros))


# Ejercicio
nombres = ["Juan", "Maria", "Pablo"]

# devolver una cadena con todos los nombres separados por un guion y en mayusculas
def concatenar(acum, nombre):
    return acum.upper() + "-" + nombre.upper()

print(reduce(concatenar, nombres))