# la funcion filter se aplica sobre una coleccion donde
# filtramos los elementos segun el valor devuelto por otra funcion
# importante, la funcion ha de devolver un valor booleano:
# True, nos quedamos el elemento, si es False, lo descartamos
# sintaxis: filter(funcion, coleccion)

# Ejemplo 1
numeros = [3,8,4,15,30]

def soloPares(numero):
    if numero % 2 == 0:
        return True
    else:
        return False
    
numerosPares = list(filter(soloPares, numeros))
print(numerosPares)


# Ejemplo 2
alumnos = dict(Luis=8.9, Maria=3.3, Adolfo=6.9)

def suspensos(item):
    if item[1] < 5:
        return True
    else:
        return False
    
alumnosSuspensos = dict(filter(suspensos, alumnos.items()))
print(alumnosSuspensos)


# Ejemplo 3
class Persona:
    def __init__(self, nombre, edad) -> None:
        self.nombre = nombre
        self.edad = edad
        
    def mostrarInfo(self) :
        print("Hola, me llamo {} y tengo {} años".format(self.nombre, self.edad))
     
personas = [Persona("Juan", 17), Persona("Maria",35), Persona("Pedro",22)]

def menoresEdad(persona: Persona):
    if persona.edad < 18:
        return True
    else:
        return False
    
menores = list(filter(menoresEdad, personas))

for person in menores:
    person.mostrarInfo()