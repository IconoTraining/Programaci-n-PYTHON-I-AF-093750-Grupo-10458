# la funcion map se aplica sobre una coleccion donde
# a cada elemento le aplicamos el resultado de otra funcion
# la funcion debe devolver un nuevo elemento o elemento modificado
# sintaxis:  map(funcion, coleccion)

# Ejemplo 1
numeros = [3,8,4,15,30]

def duplicar(numero):
    return numero * 2

numerosDobles = list(map(duplicar, numeros))
print(numerosDobles)
print(numeros)  # Principio de inmutabilidad


# Ejemplo 2
alumnos = dict(Luis=8.9, Maria=6.3, Adolfo=6.9)

def sumarPunto(item):
    return item[0], item[1] + 1

nuevasNotas = dict(map(sumarPunto, alumnos.items()))
print(nuevasNotas)


# Ejemplo 3
class Persona:
    def __init__(self, nombre, edad) -> None:
        self.nombre = nombre
        self.edad = edad
        
    def mostrarInfo(self) :
        print("Hola, me llamo {} y tengo {} años".format(self.nombre, self.edad))
     
personas = [Persona("Juan", 27), Persona("Maria",35), Persona("Pedro",22)]

def modificarPersona(persona: Persona):
    persona.nombre = persona.nombre.upper()
    persona.edad += 1
    return persona

# Si quiero modificar la lista inicial
personas = list(map(modificarPersona, personas))

for person in personas:
    person.mostrarInfo()