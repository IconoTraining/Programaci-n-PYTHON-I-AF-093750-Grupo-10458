# la funcion map se aplica sobre una coleccion donde
# a cada elemento le aplicamos el resultado de otra funcion
# la funcion debe devolver un nuevo elemento o elemento modificado
# sintaxis:  map(funcion, coleccion)

# Ejemplo 1
numeros = [3,8,4,15,30]

def duplicar(numero):
    return numero * 2

numerosDobles = list(map(duplicar, numeros))
print(numerosDobles)
print(numeros)  # Principio de inmutabilidad


# Ejemplo 2
alumnos = dict(Luis=8.9, Maria=6.3, Adolfo=6.9)

def sumarPunto(item):
    return item[0], item[1] + 1

nuevasNotas = dict(map(sumarPunto, alumnos.items()))
print(nuevasNotas)


# Ejemplo 3
