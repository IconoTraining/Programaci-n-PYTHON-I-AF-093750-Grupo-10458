# listas: colecciones ordenadas de elementos
# en todas las colecciones los elementos pueden ser de diferentes tipos
# permite tener elementos duplicados
# Se crean con []

colores = ["rojo","verde","azul"]
print(type(colores))   # list

# mostrar la lista
print(colores)

# ordenar la lista
print(sorted(colores))  # ascendente
print(sorted(colores, reverse=True)) # descendente

# Principio de inmutabilidad, me muestra la lista ordenada pero esta intacta
print(colores)

# Mostrar el color verde
print(colores[1])

# Borrar el color azul
del colores[2]   # borrar un elemento por posicion
print(colores)

# concatenar a otra lista
masColores = ['blanco', 'negro', 'rosa', 'azul']
nuevaLista = colores + masColores
print(nuevaLista)

# borrar el color rosa, solo borrar el primero que encuentra
nuevaLista.remove('rosa')   # borrar por elemento
print(nuevaLista)

# Otra forma de borrar por indice, borro el color azul
nuevaLista.__delitem__(4)
print(nuevaLista)

# Añadir un elemento al final
nuevaLista.append('naranja')
print(nuevaLista)

# Insertar un elemento en una determinada posicion
nuevaLista.insert(0, 'marron')
print(nuevaLista)

# Como podemos tener elementos duplicados
# Contar cuantos colores verde tengo
print(nuevaLista.count('verde'))

# Mostrar el indice donde se encuentra el color verde
#print(nuevaLista.index("amarillo"))   # ValueError: 'amarillo' is not in list
print(nuevaLista.index("verde"))
#print(nuevaLista.index("verde", 3))  # Busca a partir del indice 3

# longitud de la lista
print(len(nuevaLista))
print(nuevaLista.__len__())

# Mostrar el ultimo elemento de la lista
print(nuevaLista[len(nuevaLista) - 1])
print(nuevaLista[-1])

# Mostrar el tercer elemento empezando por el final
print(nuevaLista[-3])

# Mostrar los ultimos 3 elementos
print(nuevaLista[-3:])

# Mostrar todos los elementos
print(nuevaLista[:])

# Mostrar elementos desde la posicion 2 hasta la 4 (ultimo excluido)
print(nuevaLista[2:4])

# Ojo si intento hacerlo al reves
print(nuevaLista[4:2])  # muestra la lista vacia

# Mostrar desde la -4 a -2
print(nuevaLista[-4:-2])   # siempre se recorre de izquierda a derecha

# borrar todos los elementos de la lista
nuevaLista.clear()
print(nuevaLista)

# añadir un elemento
#nuevaLista = nuevaLista + ['amarillo']
nuevaLista += ['amarillo']
print(nuevaLista)