nombres = ['Luis', 'Jorge', 'Maria', 'Laura', 'Pedro']

for item in nombres :
    print(item)
print("-------- FIN --------")

''' rangos  '''
# Mostrar los numeros del 0 al 9
for numero in range(10) :  # Rango va desde 0 hasta numero-1
    print(numero)
print("-------- FIN --------")

# Mostrar los numeros del 1 al 10
for numero in range(1,11) :
    print(numero)
print("-------- FIN --------")

# Mostrar los numeros del 0 del 10 de 2 en 2
for numero in range(0,11,2) :
    print(numero)
print("-------- FIN --------")

# Mostrar desde -10 hasta -100 de 10 en 10
for numero in range(-10, -101, -10) :
    print(numero)
print("-------- FIN --------")

# Mostrar desde 10 hasta el 1
for numero in range(10,0,-1):
    print(numero)
print("-------- FIN --------")

# Mostrar todos los nombres
for i in range(len(nombres)):    # rango 0-4
    print(nombres[i])
print("-------- FIN --------")

