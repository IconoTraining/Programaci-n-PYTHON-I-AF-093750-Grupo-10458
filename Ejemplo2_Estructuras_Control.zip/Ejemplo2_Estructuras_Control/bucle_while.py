# Mostrar numeros del 1 al 10
num = 1
while num <= 10 :
    print(num)
    num += 1
print("-- FIN --")


# Recorrer una lista
nombres = ['Luis', 'Jorge', 'Maria', 'Laura', 'Pedro']
i = 0
while i < len(nombres) :
    print(nombres[i])
    i += 1
print("-- FIN --")    


# Solitar datos al usuario hasta que escriba FIN
dato = ""
while (dato != "FIN") :
    dato = input("Introduce el dato: ")

