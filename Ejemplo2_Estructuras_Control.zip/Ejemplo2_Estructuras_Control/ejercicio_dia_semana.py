'''
    Solicitar letra (l,m,x,j,v,s,d) y decir a que dia de la semana corresponde
    El usuario puede escribirlo en mayuscula o minuscula
    Ideas: or, upper, lower
'''