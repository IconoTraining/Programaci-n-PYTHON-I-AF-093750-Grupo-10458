'''
    Solicitar al usuario un numero entre 1 y 10
    comprobar si es menor que 1, mensaje de error
    comprobar si es mayor que 10, mensaje de error
    si es correcto, mostrar el mensaje
'''

numero = int(input("Introduce numero (1-10): "))

# Version 1
if numero < 1 :
    print("Error, no puede ser menor que 1")
else:
    if numero > 10 :
        print("Error, no puede ser mayor que 10")
    else :
        print("Numero correcto")
        
        
# Version 2 
if numero < 1 :
    print("Error, no puede ser menor que 1")
elif numero > 10 :
    print("Error, no puede ser mayor que 10")
else :
    print("Numero correcto")       