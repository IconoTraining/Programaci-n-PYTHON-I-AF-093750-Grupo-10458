'''
    Solicitar el pw al usuario hasta que acierte que es "curso"
    solo tiene 3 intentos
    
    break; da por terminado el bucle
    continue; da por terminada esa iteraccion y pasa a la siguiente
'''

# Version 1
'''
pw = ""
intentos = 3
while pw != "curso" :
    pw = input("Introduce pw: ")
    intentos -= 1
    if intentos == 0 :
        print("Se han agotado tus oportunidades")
        break
if pw == "curso" :
    print("Has acertado")
'''
    

# Version 2
'''
intentos = 0
while intentos < 3 :
    pw = input("Introduce pw: ")
    if pw == "curso" :
        print("Has acertado")
        break
    else :
        print("PW incorrecto")
    intentos += 1
''' 

    
# Version 3
for intento in range(3) :
    pw = input("Introduce pw: ")
    if pw == "curso" :
        print("Has acertado")
        break
    else :
        print("PW incorrecto. Te quedan", 2-intento, "intentos")
