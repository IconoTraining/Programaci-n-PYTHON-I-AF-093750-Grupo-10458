# CRUD
# C -> Create -> Insert
# R -> Read -> Select
# U -> Update -> Update
# D -> Delete -> Delete

import sqlite3

# Abrir una conexion
conexion = sqlite3.connect("Ejemplo10_BBDD/tienda.db")

# Obtener un cursor
cursor = conexion.cursor()


''' ************** Insertar datos ************** '''
# Insertar un registro
#cursor.execute("insert into PRODUCTOS values (1, 'Pantalla', 89.95)")

# Insertar varios registros con una lista de tuplas
lista = [(2, 'Teclado', 29.50), (3, 'Raton', 15), (4, 'Impresora', 120.80)]
sql = "insert into PRODUCTOS values (?,?,?)"
#cursor.executemany(sql, lista)


''' ************** Consultar datos ************** '''
# Consultar todos los productos
cursor.execute("select * from PRODUCTOS")
productos = cursor.fetchall()   # recojo todos los resultados obtenidos
for prod in productos:
    print(prod)  # cada registro es una tupla
print("------- FIN ------")



# IMPORTANTE EL COMMIT
conexion.commit()

# cerrar la conexion
conexion.close()