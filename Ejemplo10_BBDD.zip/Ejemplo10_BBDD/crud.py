# CRUD
# C -> Create -> Insert
# R -> Read -> Select
# U -> Update -> Update
# D -> Delete -> Delete

import sqlite3

# Abrir una conexion
conexion = sqlite3.connect("Ejemplo10_BBDD/tienda.db")

# Obtener un cursor
cursor = conexion.cursor()


''' ************** Insertar datos ************** '''
# Insertar un registro
#cursor.execute("insert into PRODUCTOS values (1, 'Pantalla', 89.95)")

# Insertar varios registros con una lista de tuplas
lista = [(2, 'Teclado', 29.50), (3, 'Raton', 15), (4, 'Impresora', 120.80)]
sql = "insert into PRODUCTOS values (?,?,?)"
#cursor.executemany(sql, lista)


''' ************** Consultar datos ************** '''
# Consultar todos los productos
cursor.execute("select * from PRODUCTOS")
productos = cursor.fetchall()   # recojo todos los resultados obtenidos
for prod in productos:
    print(prod)  # cada registro es una tupla
print("------- FIN ------")

# Consultar todos los productos con precio inferior a 50€
cursor.execute("select * from PRODUCTOS where precio < 50")
productos = cursor.fetchall()   # recojo todos los resultados obtenidos
for prod in productos:
    print(prod)  # cada registro es una tupla
print("------- FIN ------")

# Buscar productos cuya descripcion sea Impresora
query = "select * from PRODUCTOS where descripcion = ?"
datos = (["Impresora"])  # le pongo corchetes al ser un solo parametro
cursor.execute(query, datos)
productos = cursor.fetchall()   # recojo todos los resultados obtenidos
for prod in productos:
    print(prod)  # cada registro es una tupla
print("------- FIN ------")

# Buscar productos que valgan menos de 50€ y comiencen por letra T
query = "select * from productos where precio < ? and descripcion LIKE ? "
datos = (50, 'T%')  # si tengo mas de un parametro, no necesito corchetes
cursor.execute(query, datos)
productos = cursor.fetchall()   # recojo todos los resultados obtenidos
for prod in productos:
    print(prod)  # cada registro es una tupla
print("------- FIN ------")


''' ************** Modificar datos ************** '''
# Modificar el precio de la impresora
query = "update PRODUCTOS set precio = ? where descripcion = ?"
datos = (100, 'Impresora')
cursor.execute(query, datos)


''' ************** Eliminar datos ************** '''
query = "delete from PRODUCTOS where descripcion = ?"
dato = ("Raton", )  # ponemos la coma para engañarle a Python y que lo entienda como tupla
cursor.execute(query, dato)


# IMPORTANTE EL COMMIT
conexion.commit()

# cerrar la conexion
conexion.close()